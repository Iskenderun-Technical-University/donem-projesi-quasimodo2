using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Saga2 : MonoBehaviour
{

    
    void Start()
    {

    }

  
    void Update()
    {
        {
            Vector3 position = this.transform.position;//spawn etti�im d��manlar�m�n x ekseninde belirledi�im h�zla ilerlemesini sa�lad�m ve oyun alan�m�n d���ndaki noktaya geldi�inde yok edilmesini sa�lad�m.
            position.x += 0.04f;                       
            if (position.x >= 39f) Destroy(gameObject);
            this.transform.position = position;
        }
    }
}
