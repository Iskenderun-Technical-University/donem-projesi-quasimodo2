using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mermi : MonoBehaviour
{
    public GameObject mermi;
    
    void Start()
    {
        Destroy(mermi, 12);//olu�turdu�um mermilerin �arts�z bir �ekilde 12 saniye sonra yok edilmesini sa�lad�m.
    }

    
    void Update()
    {
        
    }
}
