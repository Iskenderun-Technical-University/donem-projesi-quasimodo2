using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mermi : MonoBehaviour
{
    public GameObject mermi;
    
    void Start()
    {
        Destroy(mermi, 12);//mermiler 12 saniye sonra yok olur.
    }

    
    void Update()
    {
        
    }
}
