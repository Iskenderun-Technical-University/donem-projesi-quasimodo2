using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mermi2 : MonoBehaviour
{
    public GameObject mermi2;
    
    void Start()
    {
        Destroy(mermi2, 12);//olu�turdu�um mermilerin �arts�z bir �ekilde 12 saniye sonra yok edilmesini sa�lad�m.
    }

    
    void Update()
    {

    }
}
