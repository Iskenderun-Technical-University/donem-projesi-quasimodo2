using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement; //sahne objelerine eri�im i�in k�t�phane kullan�m�.


public class UIManager : MonoBehaviour
{ public void restart()
    {
        SceneManager.LoadScene(0);//0 burda de�i�ken de�il sahnemin build settingsdeki de�eri,se�im i�in kulland�m yani.
        Time.timeScale = 1; //game over sahnemde oyun zaman�n� 0'a e�itleyip durdurmu�tum,tekrar ak��� sa�lamak i�in 1 yapmam gerekiyor.
    }
        


    
}