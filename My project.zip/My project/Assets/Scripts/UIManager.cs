using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;


public class UIManager : MonoBehaviour
{ public void restart()
    {
        SceneManager.LoadScene(0);
        Time.timeScale = 1; 
    }
        


    
}