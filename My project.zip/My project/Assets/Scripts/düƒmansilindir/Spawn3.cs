using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn3 : MonoBehaviour
{
    public GameObject Silindir;
    float ranY;
    float ranX;
    float ranZ;
    Vector3 whereToSpawn;
    public float spawnRate = 1f;
    public float nextSpawn = 1f;





    void Update()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate;//d��manlar spawnlan�rken ayn� yerde do�mamalar� i�in vector3 ve randomrange komutunu kullan�ld�.
            ranY = Random.Range(3f, 3f);        //oyun alan�m�n belirli noktalar� aras�nda do�malar�n� sa�land�.
            ranX = Random.Range(-38f, -38f);
            ranZ = Random.Range(10f, 40f);
            whereToSpawn = new Vector3(ranX, ranY, ranZ);


            Instantiate(Silindir, whereToSpawn, Quaternion.identity);


        }

    }
}