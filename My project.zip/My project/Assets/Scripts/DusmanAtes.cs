using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DusmanAtes : MonoBehaviour
{
    public Transform mermi2, dusmannokta;
    Transform klon2;
    public bool tekrar = true;
    

    void Start()
    {
        
    }
    void Tekrar()
    {

        tekrar = true;
    }
    
      void Update()
    {
        if (tekrar)
        {
            tekrar = false;
            Invoke("Tekrar", 2f);

         klon2 = Instantiate(mermi2, dusmannokta.position, dusmannokta.rotation);//olu�turdu�um merminin istedi�im eksen ve koordinatlarda gitmesi i�in
         klon2.GetComponent<Rigidbody>().AddForce(klon2.forward * 3000f);//merminin ��kmas�n� istedi�im yerde dusman nokta isminde bo� obje yaratt�m
                                                                           //ve o noktam�n position ve rotation de�erlerini almas�n� sa�lad�m
        }
    }
    
}
