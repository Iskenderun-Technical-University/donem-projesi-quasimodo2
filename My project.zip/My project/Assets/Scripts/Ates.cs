using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Ates : MonoBehaviour
{
    public Transform mermi, nokta;
    Transform klon;
    public bool space_uygunlugu = true;
    public bool space_uygunlugu_kiraz_degdi = false; 
    public float timer = 3.2f;
        

    void Space_Uygunlugunu_guncelleme()
    {
        
        space_uygunlugu = true;
    }

   
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && space_uygunlugu_kiraz_degdi) //�� de�i�keni ayn� anda true yapmak oyundan istedi�im �eyi vermiyordu
        {                                                                   //ben de 2'�erli halde 2 de�i�keni 've'ledim
            string res = space_uygunlugu_kiraz_degdi.ToString();
            
            klon = Instantiate(mermi, nokta.position, nokta.rotation);
            klon.GetComponent<Rigidbody>().AddForce(klon.forward * 7000f);
        }
        else if (Input.GetKeyDown(KeyCode.Space) && space_uygunlugu )
        {
            string res = space_uygunlugu_kiraz_degdi.ToString();
            
            space_uygunlugu = false;
            Invoke("Space_Uygunlugunu_guncelleme", 2.2f); //mermi atmak i�in gerekli zaman aral���

            klon = Instantiate(mermi, nokta.position, nokta.rotation); //olu�turdu�um merminin istedi�im eksen ve koordinatlarda gitmesi i�in
            klon.GetComponent<Rigidbody>().AddForce(klon.forward * 7000f);//merminin ��kmas�n� istedi�im yerde nokta isminde bo� obje yaratt�m
                                                                          //ve o noktam�n position ve rotation de�erlerini almas�n� sa�lad�m

        }

    }

   

    public void KirazdanGelen()
    {
        space_uygunlugu_kiraz_degdi = true;
        Invoke("KirazdanDolayi_Space_Uygunlugunu_guncelleme", 5f);//�d�l� ald���mda mermi at�� h�z� s�n�rlamas�n�n kald�r�lmas�
                                                                  //s�rekli olarak de�il,5 saniyeli�ine olmas�n� sa�lad�m

    }

    void KirazdanDolayi_Space_Uygunlugunu_guncelleme()
    {
        space_uygunlugu_kiraz_degdi = false;
    }

}
