using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Ates : MonoBehaviour
{
    public Transform mermi, nokta;
    Transform klon;
    public bool space_uygunlugu = true;
    public bool space_uygunlugu_kiraz_degdi = false; 
    public float timer = 3.2f;
        

    void Space_Uygunlugunu_guncelleme()
    {
        
        space_uygunlugu = true;
    }

   
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && space_uygunlugu_kiraz_degdi) //2'�erli halde 2 de�i�keni ve ile ba�lad�m.
        {                                                                   
            string res = space_uygunlugu_kiraz_degdi.ToString();
            
            klon = Instantiate(mermi, nokta.position, nokta.rotation);
            klon.GetComponent<Rigidbody>().AddForce(klon.forward * 7000f);
        }
        else if (Input.GetKeyDown(KeyCode.Space) && space_uygunlugu )
        {
            string res = space_uygunlugu_kiraz_degdi.ToString();
            
            space_uygunlugu = false;
            Invoke("Space_Uygunlugunu_guncelleme", 2.2f); //ate� etmek i�in gereken aral�k.

            klon = Instantiate(mermi, nokta.position, nokta.rotation); //ate�in istedi�im koordinatlara gitmesini istedi�im i�in.
            klon.GetComponent<Rigidbody>().AddForce(klon.forward * 7000f);//ate�in ��kmas�n� istedi�im yerde, nokta isminde bo� obje yaratt�m.
                                                                          

        }

    }

   

    public void KirazdanGelen()
    {
        space_uygunlugu_kiraz_degdi = true;
        Invoke("KirazdanDolayi_Space_Uygunlugunu_guncelleme", 5f);//�d�l al�nd���nda ate� aral��� kalkar fakat 5 saniyeli�ine.
                                                                  

    }

    void KirazdanDolayi_Space_Uygunlugunu_guncelleme()
    {
        space_uygunlugu_kiraz_degdi = false;
    }

}
