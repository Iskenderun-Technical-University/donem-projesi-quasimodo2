using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ForMe : MonoBehaviour
{
    Rigidbody rb;
    float hiz = 5f;

       
    void Start()
    {
        rb = GetComponent<Rigidbody>(); //fiziksel �zellikleri ekleyebilmek i�in rigidbody tan�mlad�m
        
    }
        
    void Update()
    {
        float yatay = Input.GetAxis("Horizontal");
        float dikey = Input.GetAxis("Vertical");
       
        Vector3 kuvvet = new Vector3(yatay, 0,0);//yatay,0,0   yerine   yatay,0,dikey �eklinde kod de�i�ikli�i sa�lad���mda kendi kontrol etti�im
                                                 //karakter yukar� ve a�a�� hareket de edebiliyor,ancak oyun alan�m k���k oldu�u i�in yapmad�m.
        rb.AddForce(kuvvet * hiz);
            
    }
}
