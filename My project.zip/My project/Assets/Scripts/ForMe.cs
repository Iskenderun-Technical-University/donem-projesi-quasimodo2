using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ForMe : MonoBehaviour
{
    Rigidbody rb;
    float hiz = 5f;

       
    void Start()
    {
        rb = GetComponent<Rigidbody>(); //Rigidbody, fiziksel �zellikler ekleyebilmek i�in eklendi.
        
    }
        
    void Update()
    {
        float yatay = Input.GetAxis("Horizontal");
        float dikey = Input.GetAxis("Vertical");
       
        Vector3 kuvvet = new Vector3(yatay, 0,0);
        rb.AddForce(kuvvet * hiz);
            
    }
}
