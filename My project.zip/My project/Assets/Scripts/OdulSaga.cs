using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OdulSaga : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        {
            Vector3 position = this.transform.position;
            
            position.z += -0.04f;//�d�l�m�n spawnlad�ktan sonra z ekseninde sabit h�zla ilerlemesini sa�lad�m
           
            if (position.z <= -58.5f)Destroy(gameObject); // z ve y eksenlerinde oyun alan�m�n d���nda olan noktalar� belirledim ve �d�l�n  
            if (position.y <= -2.5f) Destroy(gameObject); // bu alanlar�n d���na ��kt��� zaman yok edilmesini sa�lad�m

            this.transform.position = position;
        }
    }
}
