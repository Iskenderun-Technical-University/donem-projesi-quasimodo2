using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OdulSaga : MonoBehaviour
{

    
    void Start()
    {

    }

    
    void Update()
    {
        {
            Vector3 position = this.transform.position;
            
            position.z += -0.04f;//�d�l�n z ekseninde ilerlemesi sa�land�.
           
            if (position.z <= -58.5f)Destroy(gameObject); // oyunun d���nda kalan z ve y koordinatlar� belirlendi ve o �d�l�n sadece o alanlar i�inde g�r�n�r olmas� sa�land�.
            if (position.y <= -2.5f) Destroy(gameObject); 

            this.transform.position = position;
        }
    }
}
