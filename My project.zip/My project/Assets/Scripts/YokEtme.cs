using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class YokEtme : MonoBehaviour
{
  
    
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "deneme" ) //collision komutunu direkt objeye vermek yerine, objelere tag atay�p, tag'lerle komutlad�m.
        {
            
            
            Destroy(collision.gameObject);  
            Destroy(this.gameObject);       //scripti atad���m objeyi yok etmesini sa�lad�m.
        }
    }
}
