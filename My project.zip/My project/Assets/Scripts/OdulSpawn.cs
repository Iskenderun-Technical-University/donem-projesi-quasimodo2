using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OdulSpawn: MonoBehaviour
{
    public GameObject Kiraz;
    float ranY;
    float ranX;
    float ranZ;
    Vector3 whereToSpawn;
    public float spawnRate = 1f;
    public float nextSpawn = 1f;





    void Update()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate;//�d�l�m spawnlan�rken ayn� yerde do�mamas� i�in vector3 ve randomrange komutunu kulland�m
            ranY = Random.Range(3f, 6f);        //oyun alan�m�n belirli noktalar� aras�nda do�mas�n� sa�lad�m
            ranZ = Random.Range(15f, 42f);
            ranX = Random.Range(-40f, 37.5f);
            whereToSpawn = new Vector3(ranX, ranY, ranZ);


            Instantiate(Kiraz, whereToSpawn, Quaternion.identity);


        }

    }
}