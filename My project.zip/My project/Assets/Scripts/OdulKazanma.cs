using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class OdulKazanma: MonoBehaviour 
{
    Ates ates;

    void Start()
    {
       

        ates = FindObjectOfType<Ates>();//class ba�lant�s� yap�ld�.
        


    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "yoketme" )//collision komutunu direkt objeye vermek yerine, objelere tag atay�p, tag'lerle komutlad�m.
        {
            Destroy(this.gameObject);
            ates.KirazdanGelen();
          
            
        }

      
    }

    
}
