using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class YokEtme2: MonoBehaviour
{
    private UIManager UIManagerScript;
    private object collision;

    private void Awake()
    {
        UIManagerScript = GameObject.Find("UI Manager").GetComponent<UIManager>();//Unity'de olu�turdu�um UI Manager scriptine ula�mak i�in 
                                                                                  //game object find komutunu kulland�m.
    }
    private void OnCollisionEnter(Collision collision)
    {
       
        if (collision.collider.tag == "yoketme")
        {
            UIManagerScript.GetComponent<Canvas>().enabled = true; //Game over panelimin oyun ba��nda g�r�nmesini istedemedi�im i�in
            Time.timeScale = 0;                                    //panelimdeki canvas i�in enable-disable kulland�m
        }


            
    }
}

           



