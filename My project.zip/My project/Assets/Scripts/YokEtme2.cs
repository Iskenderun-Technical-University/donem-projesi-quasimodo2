using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class YokEtme2: MonoBehaviour
{
    private UIManager UIManagerScript;
    private object collision;

    private void Awake()
    {
        UIManagerScript = GameObject.Find("UI Manager").GetComponent<UIManager>();//unity'de olu�turdu�um UI Manager scriptine ula�mak i�in game object find komutunu kullan�ld�.
                                                                                  
    }
    private void OnCollisionEnter(Collision collision)
    {
       
        if (collision.collider.tag == "yoketme")
        {
            UIManagerScript.GetComponent<Canvas>().enabled = true; //Oyun bitti panelimin oyun ba��nda g�r�nmesini istedemedi�im i�in panelimdeki canvas i�in enable-disable kullan�ld�.
            Time.timeScale = 0;                                    
        }


            
    }
}

           



